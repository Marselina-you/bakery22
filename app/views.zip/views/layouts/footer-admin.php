<footer class="admin-footer">
  <div class="container-fluid admin-footer__container">
    <div class="admin-footer__author">Alferova.studio.com</div>
  </div>
</footer>