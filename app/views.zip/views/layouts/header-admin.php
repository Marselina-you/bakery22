<section class="admin-header">
  <div class="container-fluid">
    <nav class="admin-nav admin-header__nav" title="navigation">
      <ul class="admin-nav__list admin-header__list list-reset">
        <li class="admin-nav__item">
          <a href="/admin" class="admin-nav__link">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23.5 23.5"><defs><style></style></defs><path class="cls-1" d="M0,0V23.5H23.5V0ZM21.33,21.33H2.17V2.17H21.33Z"/></svg>
          <span>АдминПанель</span>
        </a></li>
        <li class="admin-nav__item"><a href="#" class="admin-nav__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23.6 23.6"><defs></defs><path d="M7.05,9.9A1.9,1.9,0,1,0,9,11.8,1.9,1.9,0,0,0,7.05,9.9Z"/><path d="M16.55,9.9a1.9,1.9,0,1,0,1.9,1.9A1.9,1.9,0,0,0,16.55,9.9Z"/><path d="M11.8,0A11.8,11.8,0,1,0,23.6,11.8,11.8,11.8,0,0,0,11.8,0Zm0,21.37h0a9.58,9.58,0,1,1,9.58-9.58h0A9.56,9.56,0,0,1,11.81,21.37Z"/></svg>
          <span><?php echo $user['name'];?></span></a></li>
        <li class="admin-nav__item"><a href="/" class="admin-nav__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.8 23.6"><path class="cls-1" d="M12.4,0,0,9,4.7,23.6H20L24.8,9Zm6.17,21.38H6.18L2.4,9.54l10-7.31L22.47,9.54Z"/></svg>
          <span>На сайт</span></a></li>
        </ul>
    </nav>
  </div>
</section>